
public class Instruction_Memory {
	String[] instructions;
	public Instruction_Memory() {
		instructions = new String[1024];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
